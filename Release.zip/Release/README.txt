A ReadMe.txt file is included stating the functionality, controls, and any additional triggers or needed information for the project to be successfully run.
--------------------------
Created By: William Inman
--------------------------
-------
DeQueue
-------
//
This Program Allows Users To Create And Modify A DeQueue Of Random Integers.
Controls Are Intuitive And Purley Integer Based, Limited To The Range ( 1 -> 8 ).
Menu Option Executes On Key Press.
Run Progam In Fullscreen For The Best Experience.
//
//
Additions: 
-Complete Debug Feedback
-ASCII Title
-getch() Input For Intuitive Use
//
//
Improvements For Next Time:
-Visual GUI
-Debug Output Is Optional
-Ablility To Input Custom Values
-Templated Nodes
//

---------
QuickSort
---------
//
This Program Allows Users To Create An Array Of Integers And Sort Them In An Ascending Or Descending Order.
Inputs Are Purley Integer Based (e.g 0,1,2,3) And Limited To The Range ( 0 -> 999999 ).
Inputs Execute On Key Press And Cannot Be Reverted.
//
//
Additions:
-Sorting Class Includes Different Optional Sorting Algorithms For Use In Other Projects And Is Now Formally Known As iSort.h
-ASCII Title
-getch() Input For Intuitive Use
//
//
Improvements For Next Time:
-Visual GUI
-Input Values From External Source (e.g .txt)
-Ablility To BackSpace Input'd Values
-Ability To Sort Again Withought Closing Program From Any Step
//
